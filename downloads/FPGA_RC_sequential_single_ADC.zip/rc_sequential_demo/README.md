# 单 DDS / 单 ADC，VIN -> OUT 顺序测试样例

本包是理想 ngspice 仿真与模型输入准备，不包含已训练模型、ICraft 编译产物或板端推理结果。
正常网表仍为 R1=R2=10kΩ，C1=100nF。固定地为节点0；DDS激励探针固定在vin。
第一次采集探针接vin，第二次接out。两次各有独立网表执行、单通道CSV和记录。
这里的电压源代表计划的理想激励，不模拟DDS/DAC实现。

## Windows 操作
解压并进入 run_sequential.py 所在目录。保持旧双通道样例不动。

```powershell
python run_sequential.py --ngspice "E:\ngspice\Spice64\bin\ngspice.exe" --out sample_rerun_sequential
python prepare_sequential_inputs.py --sample sample_rerun_sequential --out inputs_rerun_sequential.npz
```

只有ngspice实际安装路径相符时才使用上面路径。
运行仿真只需Python标准库，准备固定输入需要NumPy（缺少时 python -m pip install numpy）。
输出路径必须不存在，重跑时更换 --out。

## 顺序与时间
- 两次仿真都从新DC工作点开始，理想电容初始为0V，激励前还有1ms零输入。
- CSV列为 time_from_trigger_s,voltage_V。负时间表示激励前数据。
- 每遍801点，-1ms到+7ms，相对于各自激励上升沿；10us间隔。
- 两次记录都使用ADC0。第一遍测量vin-0，第二遍测量out-0。
- VIN末值3.3V，OUT末值约1.65V。validation.json记录解析响应校验。
- 第一次VIN不是第二次OUT的同步输入监测；不能直接当同步双通道数据处理。

## 数据
sample_sequential是本包已验证数据，sample_rerun_sequential是你运行命令后的数据。
每个测试文件夹有 wave.csv、test_action.json、measurement_record.json、simulation.cir、raw_wave.txt、ngspice.log。
measurement_history.json明确simultaneous=false和执行顺序。
label.json只作真值标签，输入脚本不读取。
circuit_graph.json是显式样例图，不是通用网表解析器结果；实体测试点和机械坐标仍未知。

## 固定输入
- X [1,16,8]：最多8元件+8节点；特征顺序R/C/电气节点/地/标称值对数/容差/容差已知/有效。
- A [1,16,16]：关联矩阵+有效顶点自身连接，CPU行归一化。
- M [1,16,1]：有效顶点。
- P [1,2,2,16]：2次测试，每次激励节点对和测量节点对；正端+1、负端-1。
- W [1,2,1,128]：2次测试×每次1通道×128点；电压除以3.3。
- S [1,2,10]：每遍低/高电压除3.3；窗起点/终点/原采样间隔/激励起点/上升/下降/脉宽/周期除1ms。
- H [1,2]：测试是否已完成；未测位置补零必须结合H使用。

例如仅使用第一遍：
```powershell
python prepare_sequential_inputs.py --sample sample_rerun_sequential --history-count 1 --out inputs_first_only.npz
```
H为[1,0]；两遍都完成时为[1,1]。
本包附带已验证的两份npz，但不是权重或可直接用于ICraft的模型。

## 实板要求与局限
撤除激励后再移动探针，重复测试前恢复相同初始状态，并按同一触发定义记录时间。
所需放电等待不能从此理想仿真直接当成实板保证，需要测量确认。
本例没有ADC噪声、激励漂移、输出阻抗、接触电阻或时序误差模型。
顺序数据不提供同步相位测量保证。正式训练要包含实测重复性误差。
128点仅用于最小部署试验，正式训练前要检查重采样是否保留所需信息。
最多8元件不是任意电路支持承诺；输入脚本当前明确限定该VIN/OUT示例。

## 下一步
确认固定输入后，建立最小联合模型，再做ICraft 3.39.0转换与悟净NPU验证。
后续多拓扑、故障注入必须在整个两次测试过程中保持同一真实电路状态，标签不能输入模型。
