import argparse, csv, json
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser()
p.add_argument('--sample',default='sample_sequential')
p.add_argument('--out',default='fixed_inputs_sequential.npz')
p.add_argument('--history-count',type=int,choices=[1,2],default=2)
args=p.parse_args()
folder=Path(args.sample);output=Path(args.out)
if output.exists():raise FileExistsError('Output exists. Choose another --out.')
graph=json.loads((folder/'circuit_graph.json').read_text(encoding='utf-8'))
history=json.loads((folder/'measurement_history.json').read_text(encoding='utf-8'))
assert history['circuit_id']==graph['circuit_id'] and history['simultaneous'] is False
assert history['acquisition_mode']=='sequential_single_adc'
assert len(history['records'])==2
components, nodes = graph['components'], graph['nodes']
assert 0 < len(components) <= 8 and 0 < len(nodes) <= 8
assert len(nodes) == len(set(nodes))
index = {name: 8 + i for i, name in enumerate(nodes)}
X = np.zeros((1, 16, 8), dtype=np.float32)
A = np.zeros((1, 16, 16), dtype=np.float32)
M = np.zeros((1, 16, 1), dtype=np.float32)
for i, component in enumerate(components):
    kind = component['type']
    assert kind in ('R', 'C')
    value = component['nominal_value']
    assert value > 0
    tolerance = component['tolerance_fraction']
    X[0, i] = [kind == 'R', kind == 'C', 0, 0,
               np.log10(value / (10000 if kind == 'R' else 1e-7)),
               0 if tolerance is None else tolerance,
               tolerance is not None, 1]
    M[0, i, 0] = 1
    for node in component['pins']:
        j = index[node]
        A[0, i, j] = A[0, j, i] = 1
for node, j in index.items():
    X[0, j] = [0, 0, 1, node == graph['ground_node'], 0, 0, 0, 1]
    M[0, j, 0] = 1
for j in np.flatnonzero(M[0, :, 0]):
    A[0, j, j] = 1
# CPU 进行行归一化；补齐的空顶点保持全零。
A /= np.maximum(A.sum(axis=2, keepdims=True), 1)

P=np.zeros((1,2,2,16),dtype=np.float32)
W=np.zeros((1,2,1,128),dtype=np.float32)
S=np.zeros((1,2,10),dtype=np.float32)
H=np.zeros((1,2),dtype=np.float32)
for i, entry in enumerate(history['records'][:args.history_count]):
    assert entry['sequence_index']==i+1
    record_path=folder/entry['record_file']
    record=json.loads(record_path.read_text(encoding='utf-8'))
    assert record['circuit_id']==graph['circuit_id']
    assert record['episode_id']==history['episode_id']
    assert record['sequence_index']==i+1 and record['status']=='complete'
    action=json.loads((record_path.parent/record['test_action_file']).read_text(encoding='utf-8'))
    assert action['action_id']==record['action_id']
    assert action['circuit_id']==graph['circuit_id']
    assert len(action['channels'])==1
    assert action['time_reference']=='commanded_stimulus_rising_edge'
    assert action['time_unit']=='s' and action['stimulus']['kind']=='pulse'
    channel=action['channels'][0]
    assert channel['channel_id']=='ADC0' and channel['unit']=='V'
    assert channel['quantity']=='voltage'
    assert channel['positive_node']==['vin','out'][i]
    for j,port in enumerate([action['stimulus'],channel]):
        P[0,i,j,index[port['positive_node']]]+=1
        P[0,i,j,index[port['negative_node']]]-=1
    with (record_path.parent/record['wave_file']).open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    t=np.array([float(r[action['time_column']]) for r in rows])
    v=np.array([float(r[channel['csv_column']]) for r in rows])
    assert len(t)==action['sample_count'] and len(t)>1
    assert np.isfinite(t).all() and np.isfinite(v).all()
    assert np.all(np.diff(t)>0)
    assert np.allclose(np.diff(t),action['sampling_interval_s'],rtol=1e-6,atol=1e-12)
    W[0,i,0]=np.interp(np.linspace(t[0],t[-1],128),t,v)/3.3
    stim=action['stimulus']['settings']
    S[0,i]=[stim['low_v']/3.3,stim['high_v']/3.3,t[0]/.001,t[-1]/.001,
        action['sampling_interval_s']/.001,0,stim['rise_s']/.001,stim['fall_s']/.001,
        stim['width_s']/.001,stim['period_s']/.001]
    H[0,i]=1
inputs=dict(X=X,A=A,M=M,P=P,W=W,S=S,H=H)
assert all(np.isfinite(v).all() for v in inputs.values())
np.savez(output,**inputs)
for key,value in inputs.items():print(key,value.shape,value.dtype)
print('History mask:',H.tolist())
print('PASS: sequential fixed inputs generated; label.json not read')
