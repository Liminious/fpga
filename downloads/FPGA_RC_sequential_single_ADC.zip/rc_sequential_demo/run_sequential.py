"""One ADC, two independent nominal ngspice tests: VIN, then OUT."""
import argparse, bisect, csv, json, math, subprocess, tempfile
from pathlib import Path

def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')

def expected(t,node):
    x,rise,tau=t-.001,1e-6,.0005
    if x<=0:return 0.
    if node=='vin':return 3.3*min(x/rise,1.)
    if x<=rise:return 1.65/rise*(x+tau*math.expm1(-x/tau))
    end=1.65/rise*(rise+tau*math.expm1(-rise/tau))
    return 1.65+(end-1.65)*math.exp(-(x-rise)/tau)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--ngspice',default='ngspice')
    p.add_argument('--out',default='sample_sequential')
    args=p.parse_args();target=Path(args.out).resolve()
    if target.exists():p.error('Output exists. Choose another --out; existing files are preserved.')
    exe=args.ngspice
    if Path(exe).is_file():exe=str(Path(exe).resolve())
    root=Path(__file__).resolve().parent
    netlist=(root/'normal.cir').read_text(encoding='utf-8')
    graph=json.loads((root/'circuit_graph.json').read_text(encoding='utf-8'))
    assert netlist.rstrip().endswith('.end')
    results=[]
    for number,node in enumerate(['vin','out'],1):
        deck=netlist.rstrip()[:-4]+f'''\n.control
set wr_singlescale
set wr_vecnames
tran 10u 8m 0 1u
wrdata raw_wave.txt v({node})
quit
.endc
.end
'''
        with tempfile.TemporaryDirectory(prefix='rc_single_adc_') as tmp:
            work=Path(tmp);(work/'simulation.cir').write_text(deck,encoding='utf-8')
            proc=subprocess.run([exe,'-b','simulation.cir'],cwd=work,capture_output=True)
            log=proc.stdout.decode('utf-8',errors='replace')+'\n'+proc.stderr.decode('utf-8',errors='replace')
            rawpath=work/'raw_wave.txt'
            if proc.returncode or not rawpath.is_file():raise RuntimeError('No waveform:\n'+log)
            rawtext=rawpath.read_text(encoding='utf-8')
            raw=[[float(v) for v in line.split()] for line in rawtext.splitlines()[1:] if line.strip()]
        assert len(raw)>1 and all(len(r)==2 and all(math.isfinite(v) for v in r) for r in raw)
        times=[r[0] for r in raw]
        assert all(b>a for a,b in zip(times,times[1:]))
        rows=[]
        for i in range(801):
            t=i*1e-5;assert times[0]-1e-12<=t<=times[-1]+1e-12
            k=min(max(bisect.bisect_right(times,t),1),len(times)-1)
            a,b=raw[k-1],raw[k]
            voltage=a[1]+(t-a[0])/(b[0]-a[0])*(b[1]-a[1])
            rows.append([t-.001,voltage])
        error=max(abs(r[1]-expected(r[0]+.001,node)) for r in rows)
        assert error<.002, f'Analytic validation failed: {error} V'
        results.append((number,node,deck,log,rawtext,rows,error))
    target.mkdir(parents=True)
    (target/'normal.cir').write_text(netlist,encoding='utf-8');save(target/'circuit_graph.json',graph)
    history=[];checks=[]
    for number,node,deck,log,rawtext,rows,error in results:
        name=f'test_{number:02d}_{node}';folder=target/name;folder.mkdir()
        for filename,content in [('simulation.cir',deck),('ngspice.log',log),('raw_wave.txt',rawtext)]:
            (folder/filename).write_text(content,encoding='utf-8')
        with (folder/'wave.csv').open('w',newline='',encoding='utf-8') as f:
            w=csv.writer(f);w.writerow(['time_from_trigger_s','voltage_V']);w.writerows(rows)
        action={'circuit_id':graph['circuit_id'],'action_id':f'T{number:03}','source':'simulation',
            'stimulus':{'positive_node':'vin','negative_node':'0','kind':'pulse',
                'settings':{'low_v':0,'high_v':3.3,'delay_s':.001,'rise_s':1e-6,'fall_s':1e-6,'width_s':.01,'period_s':.02},
                'source_impedance_ohm':0},
            'channels':[{'channel_id':'ADC0','csv_column':'voltage_V','quantity':'voltage','positive_node':node,'negative_node':'0','unit':'V'}],
            'time_column':'time_from_trigger_s','time_unit':'s','time_reference':'commanded_stimulus_rising_edge',
            'sampling_interval_s':1e-5,'sample_count':801,'trigger_time_in_simulation_s':.001,
            'initial_condition':'Fresh DC operating point; capacitor initially discharged.',
            'physical_test_points':None,'mechanical_coordinates':None,
            'note':'Ideal known trigger; no ADC, jitter, contact or source drift model.'}
        record={'record_id':f'M{number:03}','action_id':action['action_id'],'circuit_id':graph['circuit_id'],
            'episode_id':'E001','sequence_index':number,'source':'simulation','status':'complete',
            'wave_file':'wave.csv','test_action_file':'test_action.json','contact_status':'not_applicable','adc_model':None}
        save(folder/'test_action.json',action);save(folder/'measurement_record.json',record)
        history.append({'sequence_index':number,'record_file':name+'/measurement_record.json'})
        checks.append({'test':name,'points':len(rows),'end_voltage_v':rows[-1][1],'max_analytic_error_v':error})
        print(f'PASS {name}: ADC0 measures {node}-0, {len(rows)} samples, end={rows[-1][1]:.6f} V')
    save(target/'measurement_history.json',{'episode_id':'E001','circuit_id':graph['circuit_id'],
        'acquisition_mode':'sequential_single_adc','simultaneous':False,'records':history,
        'repeatability':'Same ideal circuit and source; initial state reset independently before each test.',
        'warning':'First VIN is not a simultaneous monitor of second OUT.'})
    save(target/'label.json',{'episode_id':'E001','state':'normal','label_source':'known_simulator_configuration',
        'fault_component':None,'actual_values':{'R1_ohm':10000,'R2_ohm':10000,'C1_F':1e-7},'note':'Label only, never inference input.'})
    save(target/'validation.json',{'status':'passed','independent_ngspice_runs':2,'adc_channels_per_test':1,
        'time_start_relative_to_trigger_s':-.001,'time_end_relative_to_trigger_s':.007,'checks':checks})
    print('Output:',target)
if __name__=='__main__':main()
