"""Deployment smoke test only: random weights, no diagnostic accuracy claim."""
import argparse
from collections import Counter
import json
from pathlib import Path
import numpy as np
import onnx
import onnxruntime as ort
import torch
from torch import nn

SHAPES = {'X':(1,16,8),'A':(1,16,16),'M':(1,16,1),
          'P':(1,2,2,16),'W':(1,2,1,128),'S':(1,2,10),'H':(1,2)}
NAMES = list(SHAPES)

class JointSmokeModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.vertex = nn.Linear(8, 8)
        self.wave_conv = nn.Conv2d(1, 4, (1,5), padding=(0,2))
        self.wave_pool = nn.AvgPool2d((1,4))
        self.wave_fc = nn.Linear(4*32, 8)
        self.test_fc = nn.Linear(16+8+10, 8)
        self.score = nn.Linear(8, 3)

    def forward(self, X, A, M, P, W, S, H):
        vertex = torch.relu(self.vertex(X)) * M
        vertex = torch.relu(torch.matmul(A, vertex)) * M
        ports = torch.matmul(P.reshape(1,4,16), vertex).reshape(1,2,16)
        wave = W.reshape(2,1,1,128)
        wave = self.wave_pool(torch.relu(self.wave_conv(wave)))
        wave = torch.relu(self.wave_fc(wave.reshape(2,128))).reshape(1,2,8)
        test = torch.relu(self.test_fc(torch.cat((ports,wave,S),dim=2)))
        summary = (test * H.reshape(1,2,1)).sum(dim=1,keepdim=True)
        joint = torch.relu(vertex[:,:8,:] + summary)
        return self.score(joint) * M[:,:8,:]


def run_torch(model, inputs):
    with torch.no_grad():
        return model(*[torch.from_numpy(inputs[n]) for n in NAMES]).numpy()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs',default='inputs_two_tests.npz')
    parser.add_argument('--out',default='smoke_output')
    args = parser.parse_args()
    out = Path(args.out).resolve()
    if out.exists():
        parser.error('Output exists. Choose another --out; existing files are preserved.')
    with np.load(args.inputs,allow_pickle=False) as archive:
        inputs = {n:archive[n].copy() for n in NAMES}
    for name,shape in SHAPES.items():
        value = inputs[name]
        if value.shape != shape or value.dtype != np.float32 or not np.isfinite(value).all():
            raise ValueError(f'{name}: expected finite float32 {shape}, got {value.dtype} {value.shape}')
    if not np.array_equal(inputs['H'],[[1,1]]):
        raise ValueError('Baseline must contain both completed tests (H=[1,1]).')
    # Sensitivity examples below use the included demo layout, not arbitrary graphs.
    if not (inputs['A'][0,1,9]>0 and inputs['A'][0,1,10]>0 and inputs['M'][0,8:11,0].all()):
        raise ValueError('Expected supplied RC demo: R2 at vertex1, VIN/OUT/GND at 8/9/10.')
    torch.manual_seed(20261011)
    model = JointSmokeModel().cpu().eval()
    baseline = run_torch(model,inputs)
    if baseline.shape != (1,8,3) or not np.isfinite(baseline).all():
        raise RuntimeError('PyTorch forward failed.')
    out.mkdir(parents=True)
    model_path = out/'joint_smoke.onnx'
    torch.onnx.export(model,tuple(torch.from_numpy(inputs[n]) for n in NAMES),str(model_path),
        input_names=NAMES,output_names=['component_demo_scores'],opset_version=13,
        dynamo=False,do_constant_folding=True)
    graph = onnx.load(str(model_path))
    onnx.checker.check_model(graph)
    actual_inputs = [item.name for item in graph.graph.input]
    if set(actual_inputs)!=set(NAMES):
        raise RuntimeError(f'Export dropped runtime inputs: {actual_inputs}')
    session = ort.InferenceSession(str(model_path),providers=['CPUExecutionProvider'])
    variants = {'baseline':inputs}
    changed = {n:v.copy() for n,v in inputs.items()}
    # Reconnect R2 OUT-GND -> VIN-GND. Rebuild row-normalized adjacency.
    adjacency = (changed['A'][0]>0).astype(np.float32)
    adjacency[1,9]=adjacency[9,1]=0
    adjacency[1,8]=adjacency[8,1]=1
    changed['A'][0] = adjacency / np.maximum(adjacency.sum(axis=1,keepdims=True),1)
    variants['changed_topology'] = changed
    changed = {n:v.copy() for n,v in inputs.items()}
    changed['P'][0,0,1,:]=0
    changed['P'][0,0,1,9]=1
    changed['P'][0,0,1,10]=-1
    variants['changed_measurement_mapping'] = changed
    changed = {n:v.copy() for n,v in inputs.items()}
    changed['W'][0,1] *= .8
    variants['changed_out_waveform'] = changed
    changed = {n:v.copy() for n,v in inputs.items()}
    changed['H'][0,1]=0
    variants['first_test_only'] = changed
    changed = {n:v.copy() for n,v in inputs.items()}
    changed['S'][0,:,1] *= .9
    variants['changed_stimulus_setting'] = changed
    checks = []
    for name,data in variants.items():
        reference = run_torch(model,data)
        actual = session.run(None,data)[0]
        if not np.isfinite(actual).all():
            raise RuntimeError(f'{name}: nonfinite ONNX output.')
        np.testing.assert_allclose(actual,reference,rtol=1e-4,atol=1e-5)
        difference = float(np.max(np.abs(reference-baseline)))
        if name!='baseline' and difference <= 1e-7:
            raise RuntimeError(f'{name}: output did not respond to input change.')
        checks.append({'case':name,'max_pytorch_onnx_error':float(np.max(np.abs(actual-reference))),
                       'max_change_from_baseline':difference})
        print(f'PASS {name}: ONNX error={checks[-1]["max_pytorch_onnx_error"]:.3g}, change={difference:.3g}')
    # A masked-out test must not leak its waveform into the result.
    masked = {n:v.copy() for n,v in variants['first_test_only'].items()}
    masked['W'][0,1] += 5
    np.testing.assert_allclose(run_torch(model,masked),run_torch(model,variants['first_test_only']),rtol=0,atol=1e-7)
    np.testing.assert_allclose(session.run(None,masked)[0],session.run(None,variants['first_test_only'])[0],rtol=0,atol=1e-7)
    np.testing.assert_allclose(baseline[:,3:,:],0,rtol=0,atol=0)
    ops = dict(Counter(node.op_type for node in graph.graph.node))
    torch.save(model.state_dict(),out/'random_weights.pth')
    np.save(out/'pytorch_output.npy',baseline)
    np.save(out/'onnx_output.npy',session.run(None,inputs)[0])
    np.savez(out/'verification_inputs.npz',**inputs)
    report = {'status':'passed','purpose':'Random-weight deployment smoke test; not a trained fault classifier.',
        'versions':{'torch':torch.__version__,'numpy':np.__version__,'onnx':onnx.__version__,'onnxruntime':ort.__version__},
        'opset':13,'runtime_inputs':actual_inputs,'input_shapes':SHAPES,'output_shape':[1,8,3],
        'checks':checks,'masked_test_waveform_invariance':'passed','padded_components_zero':'passed',
        'operators':ops,'icraft_compilation':'not_run','board_npu_inference':'not_run',
        'sensitivity_note':'Counterfactual numerical probes, not newly simulated physical observations or accuracy tests.'}
    (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('PASS: masked test cannot affect output; unused component slots are zero.')
    print('ONNX operators:',ops)
    print('Output:',out)
    print('NOT RUN: ICraft compilation and Wujing NPU inference.')

if __name__=='__main__':
    main()
