# 最小电路图+两次顺序测量联合模型：部署验证

这不是已经训练的故障诊断模型。权重随机，输出不是故障概率。
用途：证明固定输入能进入网络、结构与测试位置参与计算、导出的ONNX与PyTorch一致。
已在Linux CPU验证。你的Windows环境仍需复跑。

## 文件
- model_smoke.py：模型结构、PyTorch前向、ONNX导出、输出对比和输入敏感性检查。
- inputs_two_tests.npz：附带的两次顺序测量输入；可换为你自己生成的同规格文件。
- verified_cloud_output/：实际云端检查的ONNX、随机权重、输入输出及report.json。

## Windows 操作
把model_smoke.py复制到原来的 E:\ngspice\rc_sequential_demo。
确认之前生成的 inputs_two_tests.npz 在该目录。

```powershell
& "H:\anaconda_2024.06\envs\yolo\python.exe" .\model_smoke.py --inputs .\inputs_two_tests.npz --out .\smoke_output
```

也可在本包解压目录用附带输入运行上述命令。
输出目录必须不存在；重跑时换 --out 名称。
不需要开启CUDA；本脚本在CPU上检查导出一致性，不进行训练。

## 输入
X [1,16,8]，A [1,16,16]，M [1,16,1]，P [1,2,2,16]，W [1,2,1,128]，S [1,2,10]，H [1,2]。
含义及缩放沿用单ADC顺序采集包的README。
本脚本的敏感性检查明确针对附带RC样例索引：R2=1，VIN=8，OUT=9，GND=10。
测试将R2改接VIN-GND、修改测点、改变波形、遮蔽第二次测试、改变激励设置。
这些是保持其他输入不变的数值探针，不是新的物理仿真样本，也不证明诊断正确性。
脚本额外检查：被遮蔽的第二次波形不影响输出，补齐元件位置输出为零。

## 模型
元件/节点属性 -> 全连接+ReLU -> A矩阵聚合 -> P关联激励/测量节点对。
每次单通道波形 -> 二维卷积（长度方向卷积）+池化+全连接。
每次的位置特征/波形特征/激励设置 -> 全连接 -> H屏蔽未测记录 -> 求和融合。
融合结果与元件特征相加 -> 每个元件位置3个演示分数。
输出 [1,8,3]。这些3维没有绑定故障类别，第一版只为部署检查。
没有短路节点对输出、供电端口输出或参数回归，不是完整诊断模型。

## 产物
- joint_smoke.onnx：固定形状，opset13。
- random_weights.pth：随机权重，只能配合同一结构代码加载。
- verification_inputs.npz：导出验证输入。
- pytorch_output.npy / onnx_output.npy：同一输入的对照输出。
- report.json：运行版本、误差、敏感性、算子清单和未完成事项。

模型使用7个运行时输入，导出后检查全部保留。
PyTorch与ONNX比较容差为 rtol=1e-4, atol=1e-5。
云端验证版本：PyTorch2.5.0+cpu、NumPy2.3.5、ONNX1.23.2、ONNX Runtime1.31.0。
此容差仅是电脑端软件检查，不是NPU量化误差或硬件精度要求。

## 未完成
ICraft3.39.0转换/量化/编译、悟净NPU推理均未执行。
opset13和MatMul等算子能否按这里的输入形状部署，需要用ICraft目标配置验证。
下一步需提供3.39.0随附的转换示例、目标配置、悟净推理示例，不要提供密钥。
正式量化校准需要代表性真实输入，单份样例不足以验证正式量化质量。
