"""Run a nominal ngspice measurement; Python standard library only."""
import argparse
import bisect
import csv
import json
import math
from pathlib import Path
import subprocess
import tempfile


def save_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ngspice', default='ngspice', help='Executable name or full path')
    parser.add_argument('--out', default='sample_normal', help='New output directory (must not exist)')
    args = parser.parse_args()
    source = Path(__file__).resolve().parent / 'normal.cir'
    out = Path(args.out).resolve()
    if out.exists():
        parser.error('Output already exists. Choose another --out; existing files are preserved.')
    text = source.read_text(encoding='utf-8')
    lines = text.splitlines()
    if lines[-1].strip().lower() != '.end':
        raise ValueError('Expected final .end in the demo netlist')
    version_result = subprocess.run([args.ngspice, '--version'], capture_output=True, text=True, check=True)
    version = version_result.stdout.strip()
    # Actual command uses a temporary netlist; normal.cir stays unchanged.
    control = '''.control
set wr_singlescale
set wr_vecnames
tran 10u 8m 0 1u
wrdata raw_wave.txt v(vin) v(out)
quit
.endc
.end
'''
    with tempfile.TemporaryDirectory(prefix='rc_measurement_') as temporary:
        work = Path(temporary)
        (work / 'simulation.cir').write_text('\n'.join(lines[:-1]) + '\n' + control, encoding='utf-8')
        result = subprocess.run([args.ngspice, '-b', 'simulation.cir'], cwd=work,
                                capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError(f'ngspice failed ({result.returncode})\n{result.stdout}\n{result.stderr}')
        raw = work / 'raw_wave.txt'
        if not raw.is_file():
            raise RuntimeError('ngspice returned without waveform output\n' + result.stdout + result.stderr)
        parsed = []
        for line in raw.read_text().splitlines()[1:]:
            values = [float(x) for x in line.split()]
            if len(values) != 3 or not all(math.isfinite(x) for x in values):
                raise ValueError('Expected finite time, v(vin), v(out) columns')
            parsed.append(values)
        times = [r[0] for r in parsed]
        if len(times) < 2 or any(b <= a for a, b in zip(times, times[1:])):
            raise ValueError('Raw time must increase strictly')
        rows = []
        for i in range(801):
            t = i * 1e-5
            if t < times[0] - 1e-12 or t > times[-1] + 1e-12:
                raise ValueError('Raw waveform does not cover requested window')
            k = min(max(bisect.bisect_right(times, t), 1), len(times)-1)
            a, b = parsed[k-1], parsed[k]
            ratio = (t-a[0])/(b[0]-a[0])
            rows.append([t, a[1]+ratio*(b[1]-a[1]), a[2]+ratio*(b[2]-a[2])])
        # Independent physical check: finite 1 us ramp through an RC divider.
        gain, tau, delay, rise, amplitude = 0.5, 0.0005, 0.001, 0.000001, 3.3
        def expected(t):
            x = t-delay
            if x <= 0:
                return 0.0
            if x <= rise:
                return gain*amplitude/rise * (x + tau*math.expm1(-x/tau))
            at_end = gain*amplitude/rise * (rise + tau*math.expm1(-rise/tau))
            return gain*amplitude + (at_end-gain*amplitude)*math.exp(-(x-rise)/tau)
        max_error = max(abs(r[2]-expected(r[0])) for r in rows)
        if max_error > 0.002 or abs(rows[-1][2]-1.65) > 0.002:
            raise ValueError(f'Physical response validation failed: max error {max_error} V')
        out.mkdir(parents=True)
        (out / 'normal.cir').write_text(text, encoding='utf-8')
        (out / 'simulation.cir').write_text((work/'simulation.cir').read_text(), encoding='utf-8')
        (out / 'raw_wave.txt').write_bytes(raw.read_bytes())
        (out / 'ngspice.log').write_text(result.stdout+'\n'+result.stderr, encoding='utf-8')
    with (out/'wave.csv').open('w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['time_s', 'vin_V', 'vout_V'])
        writer.writerows([[format(x, '.12g') for x in row] for row in rows])
    save_json(out/'circuit_graph.json', {
        'circuit_id':'rc_divider_demo_v1', 'design_file':'normal.cir',
        'nodes':['vin','out','0'], 'ground_node':'0',
        'components':[
            {'ref':'R1','type':'R','pins':['vin','out'],'nominal_value':10000,'unit':'ohm','tolerance_fraction':None},
            {'ref':'R2','type':'R','pins':['out','0'],'nominal_value':10000,'unit':'ohm','tolerance_fraction':None},
            {'ref':'C1','type':'C','pins':['out','0'],'nominal_value':1e-7,'unit':'F','tolerance_fraction':None}],
        'note':'Explicit description of this demo, not output of the original user netlist parser.'})
    save_json(out/'test_action.json', {
        'circuit_id':'rc_divider_demo_v1','action_id':'T001','source':'simulation',
        'stimulus':{'source_ref':'V1','positive_node':'vin','negative_node':'0',
                    'kind':'pulse','settings':{'low_v':0,'high_v':3.3,'delay_s':0.001,
                    'rise_s':1e-6,'fall_s':1e-6,'width_s':0.01,'period_s':0.02},
                    'source_impedance_ohm':0},
        'channels':[
            {'channel_id':'VIN_MON','csv_column':'vin_V','quantity':'voltage','positive_node':'vin','negative_node':'0','unit':'V'},
            {'channel_id':'OUT_MON','csv_column':'vout_V','quantity':'voltage','positive_node':'out','negative_node':'0','unit':'V'}],
        'time_column':'time_s','time_unit':'s','time_reference':'simulation_start',
        'sampling_interval_s':1e-5,'sample_count':801,
        'resampling':'Linear interpolation from adaptive ngspice time steps; maximum integration step 1 us.',
        'physical_test_points':None,'mechanical_coordinates':None})
    save_json(out/'measurement_record.json', {
        'record_id':'M001','action_id':'T001','circuit_id':'rc_divider_demo_v1',
        'source':'simulation','status':'complete','wave_file':'wave.csv',
        'test_action_file':'test_action.json','contact_status':'not_applicable',
        'adc_saturation_status':'not_applicable','adc_model':None,
        'note':'Ideal simulation; not a hardware capture or measured accuracy claim.'})
    save_json(out/'label.json', {
        'label_source':'known_simulator_configuration','state':'normal',
        'fault_component':None,'fault_type':None,
        'actual_values':{'R1_ohm':10000,'R2_ohm':10000,'C1_F':1e-7},
        'note':'Training/evaluation label only. Never include this file in model input.'})
    save_json(out/'validation.json', {
        'status':'passed','ngspice_version':version,'sample_count':len(rows),
        'time_start_s':rows[0][0],'time_end_s':rows[-1][0],
        'theoretical_final_v':1.65,'simulated_end_v':rows[-1][2],
        'theoretical_time_constant_s':tau,'max_absolute_analytic_error_v':max_error,
        'analytic_error_limit_v':0.002})
    print(f'PASS: {len(rows)} samples, OUT(end)={rows[-1][2]:.6f} V, max analytic error={max_error:.8g} V')
    print(f'Output: {out}')


if __name__ == '__main__':
    main()
