# RC 测量接口仿真样例

这是使用 ngspice 实际运行得到的理想仿真样例，不是 ADC 实测或模型训练结果。
电路：R1=10kΩ（vin-out），R2=10kΩ（out-0），C1=100nF（out-0）。
激励：V1 在 vin 对 0 施加脉冲；1ms 时从 0V 上升至 3.3V，上升时间 1us。
本次只观察到 8ms，下降沿尚未发生。
测量：vin_V = V(vin)-V(0)，vout_V = V(out)-V(0)。time_s 单位为秒。
输出：801 个数据点，0到8ms，间隔10us。ngspice 自适应步长输出经过线性插值。
理想稳态 OUT=1.65V；时间常数 (R1并联R2)*C1=0.5ms。
未模拟 ADC、接触电阻、激励源误差、噪声；容差未知，未猜测。
仿真通道不代表实际硬件支持同步双通道采集。没有实体焊盘和机械坐标。

## 文件
- normal.cir：正常设计。
- run_simulation.py：独立的 Python 标准库脚本，不依赖原来的 generate.py。
- sample_normal/wave.csv：仿真波形，可用 Excel 打开。
- sample_normal/circuit_graph.json：针对本样例显式编写的连接信息；不是原网表解析器输出。
- sample_normal/test_action.json：激励、节点对、采样和列名映射。
- sample_normal/measurement_record.json：本次仿真记录，引用动作与波形。
- sample_normal/label.json：正常状态真值，只作标签，禁止作为模型输入。
- sample_normal/validation.json：仿真版本及物理响应校验。
- sample_normal/ngspice.log、raw_wave.txt、simulation.cir：实际仿真日志、原始数据、执行网表。
- sample_normal/waveform.png：波形图。

## Windows 运行
解压后，进入同时包含 normal.cir 和 run_simulation.py 的目录。
使用已有 Python 环境；需要独立版 ngspice。

```powershell
python run_simulation.py --ngspice "你的ngspice.exe完整路径" --out sample_rerun
```

例如，仅在实际安装路径相符时使用：

```powershell
python run_simulation.py --ngspice "E:\ngspice\Spice64\bin\ngspice.exe" --out sample_rerun
```

如果 ngspice 在 PATH 中：

```powershell
python run_simulation.py --out sample_rerun
```

输出目录必须不存在，防止覆盖已有数据。重复运行请换一个 --out 名称。
成功时打印 PASS，并产生 CSV、JSON 和日志。脚本不会重建附带的 PNG。
验收：801行数据（不含表头）、间隔10us、最终 OUT 接近1.65V；解析响应最大误差不超过2mV。
2mV 是此理想仿真的软件检查阈值，不是硬件精度指标。
本次在 Linux ngspice 44.2 上验证；Windows 命令未在你的电脑上执行。

## 后续
该样例只验证输入接口。不能用一个正常样本训练故障模型。
下一步先对接数据读取与节点映射，再验证最小联合模型的 ICraft/NPU 部署。
随后再设计多拓扑、单故障、多轮历史数据，按拓扑划分训练与测试。
